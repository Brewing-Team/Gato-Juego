Barn owl screech with background noise removed.

Licensing:
  - Creative Commons Attribution-ShareAlike (CC BY-SA) 4.0

Source:
  - By Luis Gracia: https://www.xeno-canto.org/345927
